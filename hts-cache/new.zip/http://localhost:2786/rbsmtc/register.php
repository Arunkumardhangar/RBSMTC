 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <style type="text/css">
        body{ padding: 20px; font: 14px sans-serif;}
        label{ display: block; }
        input[type="text"], input[type="password"]{ padding: 5px; }
        .error{ color: red; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Sign Up</h2>
        <p>Please fill this form to create an account.</p>
        <form action="/rbsmtc/register.php" method="post">
            <p>
                <label>Username:<sup>*</sup></label>
                <input type="text" name="username" value="">
                <span class="error"></span>
            </p>
            <p>
                <label>Password:<sup>*</sup></label>
                <input type="password" name="password" value="">
                <span class="error"></span>
            </p>
            <p>
                <label>Confirm Password:<sup>*</sup></label>
                <input type="password" name="confirm_password" value="">
                <span class="error"></span>
            </p>
            <input type="submit" value="Submit">
            <input type="reset" value="Reset">
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
        </form>
    </div>    
</body>
</html>