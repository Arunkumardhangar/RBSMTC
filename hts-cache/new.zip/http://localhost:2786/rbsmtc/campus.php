<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8"><title>Rbsmtc college (agra)</title>
 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
  <link href="index.css" rel="stylesheet" type="text/css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="shortcut icon" href="[favicon.ico](http://www.sitepoint.com/forums/view-source:http://www.pmob.co.uk/favicon.ico)" type="image/x-icon" /
 </head>
 <style >
 .A{
 	margin: 0;
 }
 p {
    font-family: "Times New Roman", Times, serif;
}	
 </style>
 <body>
 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
  <link href="index.css" rel="stylesheet" type="text/css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="shortcut icon" href="[favicon.ico](http://www.sitepoint.com/forums/view-source:http://www.pmob.co.uk/favicon.ico)" type="image/x-icon" />
</style><title>Rbsmtc college (agra)</title>
  <style>
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: red;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
}

#myBtn:hover {
  background-color: #555;
}

  /* Note: Try to remove the following lines to see the effect of CSS positioning */
  .affix {
      top: 0;
      width:100%;
      -webkit-transition: all .5s ease-in-out;
      transition: all .5s ease-in-out;
      background-color: #F44336;
      border-color: #F44336;
 z-index: 9999 !important;
  }
  .affix  {
      color: #fff !important;
      padding:15px !important;
      -webkit-transition: all .5s ease-in-out;
      transition: all .5s ease-in-out;
  }
  .affix-top  {
      padding: 0px !important;
  }
  .affix + .container-fluid {
      padding-top: 100px;
  }
.modal-body {
    background-image: url('https://upload.wikimedia.org/wikipedia/commons/b/bd/Emmanuel_College_Front_Court%2C_Cambridge%2C_UK_-_Diliff.jpg');
    background-repeat: no-repeat;
    background-size: cover;
    height: 300px;
}

.carousel .item {
    width: 100%; /*slider width*/
    max-height: 600px; /*slider height*/
}
.carousel .item img {
    width: 100%; /*img width*/
}
/*full width container*/
@media (max-width: 767px) {
    .block {
        margin-left: -20px;
        margin-right: -20px;
    }
}

.dropdown-content a:hover {background-color: #ddd}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #3e8e41;
}

  </style>
<div class="nav1">
<div class="container-fluid">
 <div class="row">
 <div class="col-sm-8 pull-left" style="background-color:#cc66ff;"><div class="col-md-8 col-md-offset-2"></div><h5 style="height:30px;color:white;font-weight: bold;"><p>Admission HelpLines: <span class="glyphicon glyphicon-phone" ></span>                                9411684493 &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp  Email Id: coe.rbsmtc@gmail.com  </p></h5></div>
 
<div class="col-sm-4 pull-right" style="background-color:#cc66ff;">
 <form class="navbar-form navbar-right"  method="get" action="#">
      <div class="input-group">
        <input type="text" class="form-control" name="a" placeholder=" Google Search">
        <div class="input-group-btn">
          <button class="btn btn-default" type="submit">
            <i class="glyphicon glyphicon-search"></i>
          </button>
		  </div>
        </div>
	  </div>
  </div>
</div>

<div class="himage"  >
	  <img src="images\logo2.png" class="img-responsive" alt="logo2" width="100%" height="100%"> 
	  </div>

<nav class="navbar navbar-inverse" data-spy="affix" data-offset-top="197"  style="background-color:#330033 ">
  <div class="container-fluid"> 
    <div class="collapse navbar-collapse" id="myNavbar" style="background:#330033;">
      <ul class="nav navbar-nav" style="background:#330033;">
        <li class="active"><a href="index.php">Home</a></li>
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Admission<span class="caret"></span></a>
          <ul class="dropdown-menu" style="background-color:#ff99ff;">
            <li><a href="ADDMISSION.php">Admission Procedure</a></li>
             <li class="divider"></li>
            <li><a href="fee.php">Fee Structure</a></li>
			 <li class="divider"></li>
            <li><a href="Scholarships.php">Scholarships</a></li>
          </ul>
        </li>
        <li><a href="show.php">STAFF</a></li>
        <li><a href="placement.php">PLACEMENT</a></li>
		<li><a href="campus.php">CAMPUS</a></li>
         <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Facilities<span class="caret"></span></a>
          <ul class="dropdown-menu" style="background-color:#ff99ff;">
            <li><a href="ADDMISSION.php">Library</a></li>
             <li class="divider"></li>
            <li><a href="result.php">Canteen</a></li>
       <li class="divider"></li>
            <li><a href="COMPLAINTS.php">Hostel</a></li>
       <li class="divider"></li>
             <li><a href="COMPLAINTS.php">Sports</a></li>
          </ul>
        </li>
		<li><a href="alumini.php">ALUMNI</a></li>
        <li><a href="note.php">NOTIFICATIONS</a></li>
		 <li><a href="register.php"><span class="glyphicon glyphicon-user"></span> SIGN UP</a></li>
        <li><a href="login.php"><span class="glyphicon glyphicon-log-in "></span> LOGIN</a></li>
      </ul>
    </div>
</nav>


<div id="google_translate_element"></div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<button onclick="topFunction()" id="myBtn" class="btn btn-info btn-lg" title="Go to top"><span class="glyphicon glyphicon-hand-up"></span>&nbsp;Top</button>
 
<script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}
</script>

</div>
 <div class="container-fluid">
   <div class="row">
    <div class="col-sm-8">
    <center><h2 class="A"> Location</h2><hr></center>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3548.369519441379!2d77.98982531468786!3d27.20754598300152!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39747768eaaaaaad%3A0x481097b2a7e9beb5!2sRaja+Balwant+Singh+Management+Technical+Campus!5e0!3m2!1sen!2sin!4v1521397057327" width="800" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
    <div class="col-sm-4" > 
     <center><h2 class="A">ADDRESS</h2></center><hr>
    <h3>
      <p>RAJA BALWANT SINGH MANAGEMENT TECHNICAL CAMPUS</p>
       <p>Khandari Farm Campus, Agra- 282002</p>
       <p>Ph. & Fax: 0562-2851544,4000947 </p>
        <p>e-mail: director.rbsmtc@gmail.com</p>
        <p>Website:www.rbsmtc.in</p>
        <p>EMail : admin@rbsmtc.in</p>
        <p>EMail : rbsmtc.placement@gmail.com</p>
        <p>EMail : coe.rbsmtc@gmail.com</p>
        <p>EMail : pankaj_rbs@yahoo.com </p></h3>
    </div>
  </div>


</div>
</div>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
  <link href="index.css" rel="stylesheet" type="text/css" />
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="shortcut icon" href="[favicon.ico](http://www.sitepoint.com/forums/view-source:http://www.pmob.co.uk/favicon.ico)" type="image/x-icon" />
<footer background-attachment: fixed;>
  <div class="container-fluid">
    <div class="row">
  <div class="col-md-4 col-sm-4 footerleft ">
  <hr style=" display: block;margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 5px;">
        <div class="logofooter"> Rbsmtc</div>
        <p>this college best for how want to achive our goal with cheaf investment</p>
        <p><i class="fa fa-map-pin"></i> khandhri agra </p>
        <p><i class="fa fa-phone"></i> Phone (India) : +91 8650340705</p>
      
        </div>

      <div class="col-md-2 col-sm-4 paddingtop-bottom">
    <hr style=" display: block;margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 5px;">
        <h6 class="heading7">GENERAL LINKS</h6>
        <ul class="footer-ul">
          <li><a href="#"> Career</a></li>
          <li><a href="#"> Privacy Policy</a></li>
          <li><a href="#"> Terms & Conditions</a></li>
          <li><a href="#"> Client Gateway</a></li>
          <li><a href="#"> Ranking</a></li>
          <li><a href="#"> Case Studies</a></li>
          <li><a href="#"> Frequently Ask Questions</a></li>
        </ul>
      </div>
      <div class="col-md-3 col-sm-4 paddingtop-bottom">
    <hr style=" display: block;margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 5px;">
        <h6 class="heading7">LATEST POST</h6>
        <div class="post">
          <p>m ipsum dolor sit amet, nulla vel velit vel sollicitudin sapien,<span>November 3,2017</span></p>
          <p>fm ipsum dolor sit amet, nulla vel velit vel sollicitudin sapien, <span>November 3,2017</span></p>
          <p>facm ipsum dolor sit amet, nulla vel velit vel sollicitudin sapien, <span>November 3,2017</span></p>
        </div>
      </div>
      <div class="col-md-3 col-sm-4 paddingtop-bottom">
    <hr style=" display: block;margin-top: 0.5em;
    margin-bottom: 0.5em;
    margin-left: auto;
    margin-right: auto;
    border-style: inset;
    border-width: 5px;">
        <div class="fb-page" data-href="https://www.facebook.com/facebook" data-tabs="timeline" data-height="300" data-small-header="false" style="margin-bottom:15px;" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true">
          <div class="fb-xfbml-parse-ignore">
            <blockquote cite="https://www.facebook.com/facebook"><a href="https://www.facebook.com/facebook">Facebook</a></blockquote>

      <div class="container">
      <div class="contact ">
  <a href="#" class="btn btn-info  " role="button"><p style="color:black;">For Enquiry Call Us Now: <span class="glyphicon glyphicon-phone" ></span>8650340705</p></a></br>
  <a href="#" class="fa fa-facebook"></a>
<a href="#" class="fa fa-twitter"></a>
<a href="#" class="fa fa-linkedin"></a>
<a href="#" class="fa fa-youtube"></a>
<a href="#" class="fa fa-instagram"></a>
  </div>
  </div>
<div align=center><a href='https://www.counter12.com'><img src='https://www.counter12.com/img-0b530Z24y7aa39dc-24.gif' border='0' alt='counter'></a><script type='text/javascript' src='https://www.counter12.com/ad.js?id=0b530Z24y7aa39dc'></script></div>

          </div>
        </div>
      </div>
    </dv>
  </div>
</footer>
<!--footer start from here-->
<div class="copyright">
  <div class="container">
    <div class="col-md-6">
      <p>© 2017 - All Rights with Rbsmtc</p>
    </div>
    <div class="col-md-6">
      <ul class="bottom_ul">
        <li><a href="index.php">www.rbsmtc.com</a></li>
        <li><a href="index.php">About us</a></li>
        <li><a href="index.php">Blog</a></li> 
        <li><a href="index.php">Faq's</a></li>
        <li><a href="index.php">Contact us</a></li>
        <li><a href="index.php">Site Map</a></li>
      </ul>
    </div>
  </div>
</div> 
</body>
</html>